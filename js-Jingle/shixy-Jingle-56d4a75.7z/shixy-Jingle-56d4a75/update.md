##0.4.1##
1. 修复loading框在华为、小米3等手机上出现大面积黑框的bug

##0.4##
1. 支持普通多页面开发模式，现在支持SPA和多页面模式，建议使用SPA模式进行开发,在muti(多页面模式)下data-target="section"无效
2. 重新定义服务端渲染模板方式，由之前的section上使用data-remote更改为在config中配置remotePage,hash中的querystring也会自动附加到remotePage上
3. 按钮组(controlGroup)增加change事件
4.data-icon支持左文字右图标方式
5. 增加栅格系统
6. 完善路由机制
7. form表单布局示例完善
8. 欢迎界面组件完善
9. 修复部分bug...
##0.1-0.3##
未做记录...